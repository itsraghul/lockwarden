/* lockwarden synthetic corpus — inert */
// nothing to see
