/* lockwarden synthetic corpus — inert */
