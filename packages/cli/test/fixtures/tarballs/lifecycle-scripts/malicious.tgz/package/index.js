/* lockwarden synthetic corpus — inert */
module.exports = 1;
