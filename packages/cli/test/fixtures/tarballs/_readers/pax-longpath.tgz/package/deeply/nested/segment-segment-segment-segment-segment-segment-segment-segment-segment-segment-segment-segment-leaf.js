/* lockwarden synthetic corpus — inert */
module.exports = 'long';
