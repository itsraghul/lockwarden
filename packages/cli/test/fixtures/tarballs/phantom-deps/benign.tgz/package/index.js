/* lockwarden synthetic corpus — inert */
const ms = require('ms');
module.exports = ms;
