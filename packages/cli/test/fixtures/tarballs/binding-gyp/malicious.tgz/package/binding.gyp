/* lockwarden synthetic corpus — inert */
{ "targets": [ { "target_name": "lw_inert", "sources": [] } ] }
