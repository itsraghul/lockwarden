/* lockwarden synthetic corpus — inert */
const a = require('a');
const b = require('b');
module.exports = { a, b };
