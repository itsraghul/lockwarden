/* lockwarden synthetic corpus — inert */
module.exports = require('evil-thing');
